/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.princessngoetjanaassignment;

/**
 *
 * @author lab_services_student
 */
public class PrincessNgoetjanaAssignment {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
public class Student {
    private int id;
    private String name;
    private int age;
    private String email;
    private String course;

    // Constructors, getters, setters
}
